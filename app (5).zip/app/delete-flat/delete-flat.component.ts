import { Component, OnInit } from '@angular/core';
import { Flat } from '../Flat';
import { PersonServiceService } from '../person-service.service';
import { PropertyService } from '../property.service';

@Component({
  selector: 'app-delete-flat',
  templateUrl: './delete-flat.component.html',
  styleUrls: ['./delete-flat.component.css']
})
export class DeleteFlatComponent implements OnInit {

id: number;
flat: Flat;
msg: string;
flag: boolean=false;

  constructor(private service: PropertyService) { }

  ngOnInit(): void {
  }

  flag1:boolean=false;
deleteFlat(): void{
  if(this.id!=undefined){
   this.flag1=false;
    this.flag=false;
    this.service.deleteFlat(this.id).subscribe((b)=>this.flat=b, (error: Response)=>{
      if(error.status==404)
        this.msg="Sorry Flat with id "+this.id+" not found!!";
    });
    if(this.flat == undefined){
    this.msg="Flat got deleted!!";
    this.flag=true;
    }

  }else{
  this.flag1=true;
  this.msg="Please Provide Flat Id";
  }

}
}
