import { Component, OnInit } from '@angular/core';
import { User } from '../User';
import { UserService } from '../user.service';

@Component({
  selector: 'app-register-user',
  templateUrl: './register-user.component.html',
  styleUrls: ['./register-user.component.css']
})
export class RegisterUserComponent implements OnInit {

 u: User=new User();
 msg: string;
 flag: boolean=false;

  constructor(private service: UserService) { }

  ngOnInit(): void {
  }

  registerUser(): void{
    this.service.registerUser(this.u).subscribe((usr)=>this.u=usr, (error: Response)=>{
      if(error.status==406)
        this.msg='Register unsuccessful Please Check the  Credentilas';
        this.flag=true;
    }
    );
    if(this.u!=undefined){
      this.msg='Registred Successfully';
      this.flag=true;
     alert("Registered successfully");
    }
  }

}
