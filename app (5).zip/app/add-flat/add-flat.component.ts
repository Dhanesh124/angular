import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Broker } from '../Broker';
import { Customer } from '../Customer';
import { Flat } from '../Flat';
import { Owner } from '../Owner';
import { PersonServiceService } from '../person-service.service';
import { PropertyService } from '../property.service';

@Component({
  selector: 'app-add-flat',
  templateUrl: './add-flat.component.html',
  styleUrls: ['./add-flat.component.css']
})
export class AddFlatComponent implements OnInit {

  flat : Flat=new Flat();
  
  
  
  constructor(private service: PropertyService, private personService: PersonServiceService) { 
   
  }

  ngOnInit(): void {
  }

  msg: string;
  flag:boolean=false;

   addFlat(): void{

    this.personService.getBroker(this.flat.broker.id).subscribe((b)=>this.flat.broker=b, (error: Response)=>{
      if(error.status==404)
        this.msg='Sorry  Broker with id '+ this.flat.broker.id+' not found to add';
       // alert("broker");
       this.flag=true;
    }
    );
    this.personService.getCustomer(this.flat.customer.id).subscribe((b)=>this.flat.customer=b, (error: Response)=>{
      if(error.status==404)
        this.msg='Sorry  Customer with id '+ this.flat.customer.id+' not found to add';
        this.flag=true;
    }
    );
    this.personService.getOwner(this.flat.owner.id).subscribe((b)=>this.flat.owner=b, (error: Response)=>{
      if(error.status==404)
        this.msg='Sorry  Owner with id '+ this.flat.owner.id+' not found to add';
        this.flag=true;
    }
    );
    if(this.flat.broker!=null && this.flat.owner!=null){
      this.flag=false;
    this.service.addFlat(this.flat).subscribe((f)=>this.flat=f  );
   if(this.flat!=undefined)
   this.flag=true;
         this.msg="Flat added";
    }

   }


}
