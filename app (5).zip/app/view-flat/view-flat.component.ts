import { Component, OnInit } from '@angular/core';
import { Flat } from '../Flat';
import { PropertyService } from '../property.service';

@Component({
  selector: 'app-view-flat',
  templateUrl: './view-flat.component.html',
  styleUrls: ['./view-flat.component.css']
})
export class ViewFlatComponent implements OnInit {
  
flats: Flat[];
id: number;
flat: Flat;
flag: boolean=false;
flag1: boolean=false;
flag2: boolean=false;


  constructor(private service: PropertyService) {
    
   }

  ngOnInit(): void {
  }
  flag3:boolean=false;
  msg:string;
  public getFlats():void{
    this.flag=true;
    this.flag1=false;
    this.flag2=false;
    this.flag3=false;
    
    this.service.getFlats().subscribe((f)=>this.flats=f);
    

  }

  public getFlat():void{
    this.flag1=true;
    this.flag=false;
    this.service.getFlat(this.id).subscribe((f)=>this.flat=f, (error: Response)=>{
      if(error.status==404)
        this.msg='Sorry flat with id '+this.id+' not found';
        this.flag3=true;
    }
    );
    if(this.flat!=undefined){
    this.flag2=true;
    this.flag3=false;
    }

  }

  public availableFlats(): void{
    this.flag1=false;
    this.flag=true;
    this.flag2=false;
    this.flag3=false;
    this.service.availableFlats().subscribe((f)=>this.flats=f, (error: Response)=>{
      if(error.status==404)
      this.msg='Sorry no Flats available';
        this.flag=false;
        this.flag3=true;
    }
    );
    if(this.flats!=undefined){
    this.flag=true;
    this.flag3=false;}
  }

  public soldFlats(): void{
    this.flag1=false;
    this.flag=true;
    this.flag2=false;
    this.service.soldFlats().subscribe((f)=>this.flats=f, (error: Response)=>{
      if(error.status==404)
      this.msg='Sorry no Flats Sold';
        this.flag=false;
        this.flag3=true;
    }
    );
    if(this.flats!=undefined){
    this.flag=true;
    this.flag3=false;}
  }

  public rentedFlats(): void{
    this.flag1=false;
    this.flag=true;
    this.flag2=false;
    this.service.rentedFlats().subscribe((f)=>this.flats=f, (error: Response)=>{
      if(error.status==404)
      this.msg='Sorry no Flats Rented';
        this.flag=false;
        this.flag3=true;
    }
    );
    if(this.flats!=undefined){
    this.flag=true;
    this.flag3=false;}
  }


}
