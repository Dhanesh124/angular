import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { RebApiWebURL } from './RebApiWebURL';
import { User } from './User';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  userURL: string=RebApiWebURL.userURL;

  constructor(private h: HttpClient) { }

  // public getFlats(): Observable<any>{
   // return this.h.get<any>(this.flatUrl);

  //  public addFlat(flat: Flat):Observable<any>{
  //   return this.h.post(this.flatUrl, flat, {responseType: 'text'});

  // }

  public getUsers():Observable<any>{
    return this.h.get<any>(this.userURL);
  }

  public registerUser(user: User): Observable<any>{
    return this.h.post(this.userURL, user, {responseType: 'text'});

  }

  public deleteUser(id: number): Observable<any>{
    return this.h.delete(this.userURL+"/"+id ,{responseType: 'text'});

  }

  public loginUser(user: User): Observable<any>{
    return this.h.post(this.userURL+"/login", user,{responseType: 'text'});
  }

  public getUser(id: number): Observable<any>{
    return this.h.get<any>(this.userURL+"/"+id);
  }
}
