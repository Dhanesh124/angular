export class Address{
    id: number;
    streetNo: string;
    streetName: string;
    city: string;
    state: string;
    country: string;
    pincode: number;
    
}