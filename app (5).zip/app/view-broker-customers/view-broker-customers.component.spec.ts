import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewBrokerCustomersComponent } from './view-broker-customers.component';

describe('ViewBrokerCustomersComponent', () => {
  let component: ViewBrokerCustomersComponent;
  let fixture: ComponentFixture<ViewBrokerCustomersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewBrokerCustomersComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewBrokerCustomersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
