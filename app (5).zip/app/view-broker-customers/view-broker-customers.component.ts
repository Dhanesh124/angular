import { Component, OnInit } from '@angular/core';
import { Broker } from '../Broker';
import { Customer } from '../Customer';
import { PersonServiceService } from '../person-service.service';

@Component({
  selector: 'app-view-broker-customers',
  templateUrl: './view-broker-customers.component.html',
  styleUrls: ['./view-broker-customers.component.css']
})
export class ViewBrokerCustomersComponent implements OnInit {
id: number;


customers: Customer[]=[];
brokerCustomers: Customer[]=[];

flag: boolean=false;
  constructor(private service: PersonServiceService) { }

  ngOnInit(): void {
  }

  getBrokerCustomers(): void{
    
    this.flag=true;
    this.service.getCustomers().subscribe((c)=>this.customers=c);
    
   //this.brokerCustomers=this.customers.filter((cust)=>cust.broker.id==325);
   // alert(this.brokerCustomers[0].broker.id);
    
  }

}
