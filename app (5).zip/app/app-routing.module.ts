import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddBrokerComponent } from './add-broker/add-broker.component';
import { AddCustomerComponent } from './add-customer/add-customer.component';
import { AddFlatComponent } from './add-flat/add-flat.component';
import { AddOwnerComponent } from './add-owner/add-owner.component';
import { AddPlotComponent } from './add-plot/add-plot.component';
import { AddShopComponent } from './add-shop/add-shop.component';
import { AuthGuard } from './auth.guard';
import { BrokerComponent } from './broker/broker.component';
import { CustomerComponent } from './customer/customer.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { DeleteBrokerComponent } from './delete-broker/delete-broker.component';
import { DeleteCustomerComponent } from './delete-customer/delete-customer.component';
import { DeleteFlatComponent } from './delete-flat/delete-flat.component';
import { DeleteOwnerComponent } from './delete-owner/delete-owner.component';
import { DeletePlotComponent } from './delete-plot/delete-plot.component';
import { DeleteShopComponent } from './delete-shop/delete-shop.component';
import { DeleteUserComponent } from './delete-user/delete-user.component';
import { FlatComponent } from './flat/flat.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';

import { PlotComponent } from './plot/plot.component';
import { RegisterUserComponent } from './register-user/register-user.component';
import { SearchBrokerComponent } from './search-broker/search-broker.component';
import { SearchCustomerComponent } from './search-customer/search-customer.component';
import { SearchFlatComponent } from './search-flat/search-flat.component';
import { SearchPlotComponent } from './search-plot/search-plot.component';
import { SearchShopComponent } from './search-shop/search-shop.component';

import { UpdateBrokerComponent } from './update-broker/update-broker.component';
import { UpdateCustomerComponent } from './update-customer/update-customer.component';
import { UpdateFlatComponent } from './update-flat/update-flat.component';
import { UpdateOwnerComponent } from './update-owner/update-owner.component';
import { UpdatePlotComponent } from './update-plot/update-plot.component';
import { UpdateShopComponent } from './update-shop/update-shop.component';
import { UpdateUserComponent } from './update-user/update-user.component';

import { ViewBrokerCustomersComponent } from './view-broker-customers/view-broker-customers.component';
import { ViewBrokerComponent } from './view-broker/view-broker.component';
import { ViewCustomerComponent } from './view-customer/view-customer.component';
import { ViewFlatComponent } from './view-flat/view-flat.component';
import { ViewOwnerComponent } from './view-owner/view-owner.component';
import { ViewPlotComponent } from './view-plot/view-plot.component';
import { ViewShopComponent } from './view-shop/view-shop.component';
import { ViewUserComponent } from './view-user/view-user.component';

const routes: Routes = [
  {
    path: '',
    component: LoginComponent
  },
  {
    path: 'dashboard/viewflat',
    component: ViewFlatComponent
  },
  {
    path: 'dashboard/viewplot',
    component: ViewPlotComponent
   },
  {
    path: 'dashboard/viewshop',
    component: ViewShopComponent
  },
  {
    path: 'dashboard/viewbroker',
    component:ViewBrokerComponent 
  },
  {
    path: 'dashboard/viewcustomer',
    component:ViewCustomerComponent 
  },
  {
    path: 'dashboard/viewowner',
    component:ViewOwnerComponent 
  },
  {
    path: 'dashboard/deletebroker',
    component:DeleteBrokerComponent 
  },
  {
    path: 'dashboard/deletecustomer',
    component:DeleteCustomerComponent 
  },
  {
    path: 'dashboard/deleteowner',
    component:DeleteOwnerComponent 
  },
  {
    path: 'dashboard/deleteflat',
    component:DeleteFlatComponent 
  },
  {
    path: 'dashboard/deleteplot',
    component:DeletePlotComponent
  },
  {
    path: 'dashboard/deleteshop',
    component:DeleteShopComponent 
  },
  {
    path: 'dashboard/deletebroker',
    component:DeleteBrokerComponent 
  },
  {
    path: 'dashboard/addbroker',
    component:AddBrokerComponent
  },
  {
    path: 'dashboard/addcustomer',
    component:AddCustomerComponent
  },
  {
    path: 'dashboard/addowner',
    component:AddOwnerComponent
  },
  {
    path: 'dashboard/addflat',
    component:AddFlatComponent
  },
  {
    path: 'dashboard/addplot',
    component:AddPlotComponent
  },
  {
    path: 'dashboard/addshop',
    component:AddShopComponent
  },
  {
    path: 'dashboard/updatebroker',
    component: UpdateBrokerComponent
  },
  {
    path: 'dashboard/updatecustomer',
    component: UpdateCustomerComponent
  },
  {
    path:'dashboard/updateowner',
    component: UpdateOwnerComponent
  },
  {
    path:'dashboard/updateflat',
    component: UpdateFlatComponent
  },
  {
    path:'dashboard/updateplot',
    component: UpdatePlotComponent
  },
  {
    path: 'dashboard/updateshop',
    component: UpdateShopComponent
  },
  {
    path: 'broker',
    component: BrokerComponent
  },
  {
    path:'customer',
    component: CustomerComponent
  },
  
  {
    path: 'flat',
    component: FlatComponent
  },
  
  {
    path: 'plot',
    component: PlotComponent
  },
  {
    path: 'brokercustomers',
    component: ViewBrokerCustomersComponent
  },
  {
    path: 'dashboard/searchflat',
    component: SearchFlatComponent
  },
  {
    path: 'dashboard/searchplot',
    component: SearchPlotComponent
  },
  {
    path: 'dashboard/searchshop',
    component: SearchShopComponent
  },
  {
    path: 'dashboard/searchbroker',
    component: SearchBrokerComponent
  },
  {
    path: 'dashboard/searchcustomer',
    component: SearchCustomerComponent
  },
  {
    path: 'dashboard/searchowner',
    component: SearchCustomerComponent
  },
  {
    path: 'signup',
    component: RegisterUserComponent
  },
  {
    path: 'signin',
    component: LoginComponent
  },
  {
  path: 'dashboard/deleteuser',
  component: DeleteUserComponent
  },
  {
    path: 'dashboard/updateuser',
    component: UpdateUserComponent
  },
  {
    path: 'dashboard/viewuser',
    component: ViewUserComponent
  },
  {
    path: 'dashboard',
    component: DashboardComponent,
    canActivate: [AuthGuard]

  }
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
