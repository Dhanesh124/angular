import { Component, OnInit } from '@angular/core';
import { Broker } from '../Broker';
import { PersonServiceService } from '../person-service.service';

@Component({
  selector: 'app-delete-broker',
  templateUrl: './delete-broker.component.html',
  styleUrls: ['./delete-broker.component.css']
})
export class DeleteBrokerComponent implements OnInit {
id: number;
broker: Broker;
msg: string;
flag: boolean=false;

  constructor(private service: PersonServiceService) { }

  ngOnInit(): void {
  }

  flag1: boolean=false;
deleteBroker(): void{
   if(this.id!=undefined){
   this.flag1=false;
    this.flag=false;
    this.service.deleteBroker(this.id).subscribe((b)=>this.broker=b, (error: Response)=>{
      if(error.status==404)
        this.msg="Sorry Broker with id "+this.id+" not found!!";
    });

    if(this.broker==undefined){
    this.msg="Broker got deleted!!";
    this.flag=true;
  //this.id=undefined;
    }
 }else{
   this.flag1=true;
  this.msg="Please Provide Broker Id";
}

}

}
