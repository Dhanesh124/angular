import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteBrokerComponent } from './delete-broker.component';

describe('DeleteBrokerComponent', () => {
  let component: DeleteBrokerComponent;
  let fixture: ComponentFixture<DeleteBrokerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DeleteBrokerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteBrokerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
