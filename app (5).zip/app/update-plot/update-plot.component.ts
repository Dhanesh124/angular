import { Component, OnInit } from '@angular/core';
import { PersonServiceService } from '../person-service.service';
import { Plot } from '../Plot';
import { PropertyService } from '../property.service';

@Component({
  selector: 'app-update-plot',
  templateUrl: './update-plot.component.html',
  styleUrls: ['./update-plot.component.css']
})
export class UpdatePlotComponent implements OnInit {
  id: number;
  plot: Plot=new Plot();
  msg:string;
  flag: boolean=false;
  flag1: boolean=false;
  flag2: boolean=false;
    constructor(private service: PropertyService, private personService: PersonServiceService) { }
  
    ngOnInit(): void {
    }
    getPlot(): void{
      this.flag1=false;
      this.flag2=false;
      this.service.getPlot(this.id).subscribe((p)=>this.plot=p,(error: Response)=>{
        if(error.status== 404){
          this.msg='Sorry  Plot with id '+ this.id+' not there to update';
          this.flag2=true;
          this.flag=false;
        }
      });
      
      if(this.plot != undefined)
       this.flag2=false;
       this.flag=true;
    }
  
    updatePlot(): void{
      this.personService.getBroker(this.plot.broker.id).subscribe((b)=>this.plot.broker=b, (error: Response)=>{
        if(error.status==404)
          this.msg='Sorry  Broker with id '+ this.plot.broker.id+' not found to add';
         // alert("broker");
         this.flag=true;
      }
      );
      this.personService.getCustomer(this.plot.customer.id).subscribe((b)=>this.plot.customer=b, (error: Response)=>{
        if(error.status==404)
          this.msg='Sorry  Customer with id '+ this.plot.customer.id+' not found to add';
          this.flag=true;
      }
      );
      this.personService.getOwner(this.plot.owner.id).subscribe((b)=>this.plot.owner=b, (error: Response)=>{
        if(error.status==404)
          this.msg='Sorry  Owner with id '+ this.plot.owner.id+' not found to add';
          this.flag=true;
      }
      );
      this.flag1=true;
      this.flag=false;
      this.service.addPlot(this.plot).subscribe((p)=>this.plot=p);
      this.msg="Plot got updated!!";
    }

}
