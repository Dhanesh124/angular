import { Component, OnInit } from '@angular/core';
import { Broker } from '../Broker';
import { Customer } from '../Customer';
import { Owner } from '../Owner';
import { PersonServiceService } from '../person-service.service';
import { PropertyService } from '../property.service';
import { Shop } from '../Shop';

@Component({
  selector: 'app-add-shop',
  templateUrl: './add-shop.component.html',
  styleUrls: ['./add-shop.component.css']
})
export class AddShopComponent implements OnInit {

  shop: Shop=new Shop();
  
    constructor(private service: PropertyService, private personService: PersonServiceService) { }
  

  ngOnInit(): void {
  }

  msg: string;
  flag:boolean=false;

   addShop(): void{

    this.personService.getBroker(this.shop.broker.id).subscribe((b)=>this.shop.broker=b, (error: Response)=>{
      if(error.status==404)
        this.msg='Sorry  Broker with id '+ this.shop.broker.id+' not found to add';
       // alert("broker");
       this.flag=true;
    }
    );
    this.personService.getCustomer(this.shop.customer.id).subscribe((b)=>this.shop.customer=b, (error: Response)=>{
      if(error.status==404)
        this.msg='Sorry  Customer with id '+ this.shop.customer.id+' not found to add';
        this.flag=true;
    }
    );
    this.personService.getOwner(this.shop.owner.id).subscribe((b)=>this.shop.owner=b, (error: Response)=>{
      if(error.status==404)
        this.msg='Sorry  Owner with id '+ this.shop.owner.id+' not found to add';
        this.flag=true;
    }
    );
    if(this.shop.broker!=null && this.shop.owner!=null){
      this.flag=false;
    this.service.addShop(this.shop).subscribe((s)=>this.shop=s
    );
   if(this.shop!=undefined)
   this.flag=true;
         this.msg="Shop added";
    }

   }

}
