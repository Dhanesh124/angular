import { Component, OnInit } from '@angular/core';
import { Plot } from '../Plot';
import { PropertyService } from '../property.service';

@Component({
  selector: 'app-delete-plot',
  templateUrl: './delete-plot.component.html',
  styleUrls: ['./delete-plot.component.css']
})
export class DeletePlotComponent implements OnInit {

  id: number;
plot: Plot;
msg: string;
flag: boolean=false;

  constructor(private service: PropertyService) { }

  ngOnInit(): void {
  }

  flag1:boolean=false;
  deletePlot(): void{
      if(this.id!=undefined){
      this.flag1=false;
    this.flag=false;
      this.service.deletePlot(this.id).subscribe((p)=>this.plot=p, (error: Response)=>{
        if(error.status==404)
          this.msg="Sorry Plot with id "+this.id+" not found!!";
      });
      if(this.plot==undefined){
      this.msg="Plot got deleted!!";
      this.flag=true;
      }
  
    }else{
      this.flag1=true;
      this.msg="please provide plot id";
     }
    }
}
