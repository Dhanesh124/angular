import { Address } from "./Address";
import { Customer } from "./Customer";
import { Flat } from "./Flat";
import { Plot } from "./Plot";
import { Shop } from "./Shop";

export class Owner{
    id: number;
    firstName: string;
    lastName: string;
    contact : string;
    email: string;
    ownerAddress: Address=new Address();
    // customer: Customer=new Customer();
    // flat : Flat=new Flat();
    // plot : Plot=new Plot();
    // shop : Shop=new Shop();

}