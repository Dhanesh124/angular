import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ActivatedRouteSnapshot, Router } from '@angular/router';
import { User } from '../User';
import { UserService } from '../user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  u: User=new User();
  msg: string;
  flag: boolean=false;
  m: string;
 
   constructor(private service: UserService, private r: Router) { }
 
   ngOnInit(): void {
   }
 
   loginUser(): void{
     this.service.loginUser(this.u).subscribe((usr)=>this.m=usr, (error: Response)=>{
       if(error.status == 406){
         //this.msg='Login Unsuccessfull  Please Check the Login Credentials';
         //this.flag=true;
         alert("Please Provide right credentials")
       }
     }
     );
     if(this.m!=undefined && !this.flag){
       this.msg="Welcome";
       this.r.navigate(['dashboard']);    
      this.flag=true;
     }
   }

  // loginUser(): void{
  //   this.service.loginUser(this.u).subscribe((usr)=>this.m=usr);
  //   alert(this.m);
  //   if(this.m==true){
     
  //     localStorage.setItem('password', this.u.password);
  //     this.r.navigate(['/dashboard']);
  //   }
  //   else{
  //    // alert("Invalid username or password");
  //    this.msg='Login Unsuccessfull  Please Check the Login Credentials';
  //         this.flag=true;
     
  //   }
    
  // }

}
