import { Address } from "./Address";
import { Customer } from "./Customer";
import { Flat } from "./Flat";
import { Plot } from "./Plot";
import { Shop } from "./Shop";


export class Broker{
    id: number;
    brokerFirstName: string;
    brokerLastName: string;
    contact: number;
    email: string;
    brokerAddress:Address= new Address();
    

}