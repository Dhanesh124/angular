import { Component, OnInit } from '@angular/core';
import { Owner } from '../Owner';
import { PersonServiceService } from '../person-service.service';
import { PropertyService } from '../property.service';

@Component({
  selector: 'app-search-owner',
  templateUrl: './search-owner.component.html',
  styleUrls: ['./search-owner.component.css']
})
export class SearchOwnerComponent implements OnInit {

  owners: Owner[];
  searched: Owner[];
  city: string;
  name: string;
  flag:boolean=false;
    constructor(private service: PersonServiceService) { 
        this.service.getOwners().subscribe((o)=>this.owners=o);
    }
    ngOnInit(): void {
    }
    searchOwner(): void{
        this.flag=true;
      this.searched=this.owners.filter((o)=>o.ownerAddress.city.startsWith(this.city));
    }
    searchOwnerName(): void{
        this.flag=true;
            this.searched=this.owners.filter((o)=>o.firstName.startsWith(this.name));
              }

}
