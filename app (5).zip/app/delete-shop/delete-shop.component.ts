import { ThisReceiver } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { PropertyService } from '../property.service';
import { Shop } from '../Shop';

@Component({
  selector: 'app-delete-shop',
  templateUrl: './delete-shop.component.html',
  styleUrls: ['./delete-shop.component.css']
})
export class DeleteShopComponent implements OnInit {

  id: number;
  shop: Shop;
  msg: string;
  flag: boolean=false;
  
  
    constructor(private service: PropertyService) { }
  
    ngOnInit(): void {
    }
    flag1: boolean=false;
    deleteShop(): void{
      if(this.id!=undefined){
        this.flag1=false;
      this.flag=false;
      this.service.deleteShop(this.id).subscribe((s)=>this.shop=s, (error: Response)=>{
        if(error.status==404)
          this.msg="Sorry Shop with id "+this.id+" not found!!";
      });
    
      if(this.shop==undefined){
      this.msg="Shop got deleted!!";
      this.flag=true;
      //this.id=undefined;
      }
    }else{
      this.flag1=true;
      this.msg="please provide shop id";
    }
  
    }

}
