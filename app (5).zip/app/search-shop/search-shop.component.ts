import { Component, OnInit } from '@angular/core';
import { PropertyService } from '../property.service';
import { Shop } from '../Shop';

@Component({
  selector: 'app-search-shop',
  templateUrl: './search-shop.component.html',
  styleUrls: ['./search-shop.component.css']
})
export class SearchShopComponent implements OnInit {

  shops: Shop[];
  searched: Shop[];
  id:number;
  oid: number;
  cid: number;
  city: string;
  name: string;
  flag:boolean=false;
    constructor(private service: PropertyService) { 
      this.service.getShops().subscribe((s)=>this.shops=s);
      
    }
  
    ngOnInit(): void {
     
    }
  
    searchShop(): void{
      this.flag=true;
  
      this.searched=this.shops.filter((s)=>s.shopAddress.city.startsWith(this.city));
  
    }
  
    searchShopName(): void{
      this.flag=true;
      this.searched=this.shops.filter((s)=>s.shopName.startsWith(this.name));
    }

    searchBrokerShops(): void{
      this.flag=true;
      this.searched=this.shops.filter((s)=>s.broker.id.toString().startsWith(this.id.toString()));
    }

    searchCustomerShops(): void{
      this.flag=true;
      this.searched=this.shops.filter((s)=>s.customer.id.toString().startsWith(this.cid.toString()));
    }

    searchOwnerShops(): void{
      this.flag=true;
      this.searched=this.shops.filter((s)=>s.owner.id.toString().startsWith(this.oid.toString()));
    }

}
