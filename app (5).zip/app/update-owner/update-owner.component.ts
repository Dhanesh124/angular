import { Component, OnInit } from '@angular/core';
import { Owner } from '../Owner';
import { PersonServiceService } from '../person-service.service';

@Component({
  selector: 'app-update-owner',
  templateUrl: './update-owner.component.html',
  styleUrls: ['./update-owner.component.css']
})
export class UpdateOwnerComponent implements OnInit {

  id: number;
  owner: Owner=new Owner();
  msg:string;
  flag: boolean=false;
  flag1: boolean=false;
  flag2: boolean=false;
    constructor(private service: PersonServiceService) { }
  
    ngOnInit(): void {
    }
    getOwner(): void{
      this.flag1=false;
      this.flag2=false;
      this.service.getOwner(this.id).subscribe((o)=>this.owner=o,(error: Response)=>{
        if(error.status== 404){
          this.msg='Sorry  Owner with id '+ this.id+' not there to update';
          this.flag2=true;
          this.flag=false;
        }
      });
      
      if(this.owner != undefined)
       this.flag2=false;
       this.flag=true;
    }
  
    updateOwner(): void{
      this.flag1=true;
      this.flag=false;
      this.service.addOwner(this.owner).subscribe((o)=>this.owner=o);
      this.msg="Owner got updated!!";
    }

}
