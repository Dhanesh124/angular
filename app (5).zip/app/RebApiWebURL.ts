export class RebApiWebURL{
    public static brokerURL: string="http://localhost:9090/api/brokers";
    public static customerURL: string="http://localhost:9090/api/customers";
    public static ownerURL: string="http://localhost:9090/api/owners";
    public static flatURL: string="http://localhost:9090/api/flats";
    public static plotURL: string="http://localhost:9090/api/plots";
    public static shopURL: string="http://localhost:9090/api/shops";
    public static userURL: string="http://localhost:9090/api/users";
    

    

}