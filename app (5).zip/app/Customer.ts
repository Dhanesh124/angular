import { Address } from "./Address";
import { Broker } from "./Broker";
import { Flat } from "./Flat";
import { Owner } from "./Owner";
import { Plot } from "./Plot";
import { Shop } from "./Shop";
import { ViewBrokerPropertiesComponent } from "./view-broker-properties/view-broker-properties.component";

export class Customer{
    id: number;
    customerFirstName: string;
    customerLastName: string;
    customerContact: number;
    email:string;
    customerAddress: Address= new Address();
    // broker: Broker=new Broker();
    // owner: Owner=new Owner();
    // flat : Flat=new Flat();
    // plot : Plot=new Plot();
    // shop : Shop=new Shop();
    }