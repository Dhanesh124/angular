import { Component, OnInit } from '@angular/core';
import { Plot } from '../Plot';
import { PropertyService } from '../property.service';

@Component({
  selector: 'app-view-plot',
  templateUrl: './view-plot.component.html',
  styleUrls: ['./view-plot.component.css']
})
export class ViewPlotComponent implements OnInit {

  plots: Plot[];
  plot: Plot;
  id:  number;
  flag: boolean=false;
  flag1: boolean=false;
  flag2: boolean=false;
  constructor(private service: PropertyService) { }

  ngOnInit(): void {
  }

  flag3:boolean=false;
  msg:string;
  public getPlots():void{
    this.flag=true;
    this.flag1=false;
    this.flag2=false;
    this.flag3=false;
    
    this.service.getPlots().subscribe((p)=>this.plots=p);
    

  }

  public getPlot():void{
    this.flag1=true;
    this.flag=false;
    this.service.getPlot(this.id).subscribe((p)=>this.plot=p, (error: Response)=>{
      if(error.status==404)
        this.msg='Sorry plot with id '+this.id+' not found';
        this.flag3=true;
    }
    );
    if(this.plot!=undefined){
    this.flag2=true;
    this.flag3=false;
    }

  }

  public availablePlots(): void{
    this.flag1=false;
    this.flag=true;
    this.flag2=false;
    this.service.availablePlots().subscribe((p)=>this.plots=p, (error: Response)=>{
      if(error.status==404)
      this.msg='Sorry no Plots available';
        this.flag=false;
        this.flag3=true;
    }
    );
    if(this.plots!=undefined){
    this.flag=true;
    this.flag3=false;}
  }

  public soldPlots(): void{
    this.flag1=false;
    this.flag=true;
    this.flag2=false;
    this.service.soldPlots().subscribe((p)=>this.plots=p, (error: Response)=>{
      if(error.status==404)
      this.msg='Sorry no Plots Sold';
        this.flag=false;
        this.flag3=true;
    }
    );
    if(this.plots!=undefined){
    this.flag=true;
    this.flag3=false;}
  }

  public rentedPlots(): void{
    this.flag1=false;
    this.flag=true;
    this.flag2=false;
    this.service.rentedPlots().subscribe((p)=>this.plots=p, (error: Response)=>{
      if(error.status==404)
      this.msg='Sorry no Plots Rented';
        this.flag=false;
        this.flag3=true;
    }
    );
    if(this.plots!=undefined){
    this.flag=true;
    this.flag3=false;}
  }

}
