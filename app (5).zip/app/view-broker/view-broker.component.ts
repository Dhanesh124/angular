import { Component, OnInit } from '@angular/core';
import { Broker } from '../Broker';
import { PersonServiceService } from '../person-service.service';

@Component({
  selector: 'app-view-broker',
  templateUrl: './view-broker.component.html',
  styleUrls: ['./view-broker.component.css']
})
export class ViewBrokerComponent implements OnInit {
  brokers:Broker[];
  broker: Broker;
  id: number;
  flag:boolean=false;
  flag1:boolean=false;
  flag2: boolean=false;

  totalrecords: any;
  page: number=1;
 
  constructor(private service: PersonServiceService) { }

  ngOnInit(): void {
  }
  flag3:boolean=false;
  msg:string;
  getBrokers(): void{

    // this.s.getCustomer().subscribe((result)=>{
    //   this.showPost=result;
    //   this.totalRecords=result.length;
    // });
   
    this.flag1=false;
    this.flag3=false;
    // this.service.getBrokers().subscribe((b)=>this.brokers=b, (error: Response)=>{
    //   if(error.status==404)
    //     this.msg='Sorry no Brokers to show';
    //     this.flag3=false;
        
    // }
    // );
    this.service.getBrokers().subscribe((result)=>{
      this.brokers=result;
      this.totalrecords=result.length;

    });
    if(this.brokers!=undefined){
    this.flag=true;
    this.flag2=false;
    }

  }

  getBroker(): void{
    this.flag=false;
    this.flag1=true;

    this.service.getBroker(this.id).subscribe((b)=>this.broker=b, (error: Response)=>{
      if(error.status == 404){
        this.msg='Sorry  Broker with id '+ this.id+' not found to show';
        this.flag3=true;
      }
    }
    );
    if(this.broker!=undefined){
    this.flag2=true;
    this.flag3=false;

    }
  }

}
