import { Address } from "./Address";
import { Broker } from "./Broker";
import { Customer } from "./Customer";
import { Owner } from "./Owner";

export class Shop{
    shopId: number;
    shopName: string;
    noOfRooms: number;
    squareFeet: number;
    price: number;
    status: string;
    shopAddress: Address= new Address();
    broker: Broker=new Broker();
    customer: Customer= new Customer();
    owner: Owner= new Owner();

}