import { Component, OnInit } from '@angular/core';
import { Owner } from '../Owner';
import { PersonServiceService } from '../person-service.service';

@Component({
  selector: 'app-add-owner',
  templateUrl: './add-owner.component.html',
  styleUrls: ['./add-owner.component.css']
})
export class AddOwnerComponent implements OnInit {

  owner : Owner=new Owner();
  constructor(private service: PersonServiceService) { }

  ngOnInit(): void {
  }

  addOwner(): void{
    this.service.addOwner(this.owner).subscribe((b)=>this.owner=b);
    alert("Owner added");

  }

}
