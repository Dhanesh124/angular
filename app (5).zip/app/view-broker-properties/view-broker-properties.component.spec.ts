import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewBrokerPropertiesComponent } from './view-broker-properties.component';

describe('ViewBrokerPropertiesComponent', () => {
  let component: ViewBrokerPropertiesComponent;
  let fixture: ComponentFixture<ViewBrokerPropertiesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewBrokerPropertiesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewBrokerPropertiesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
