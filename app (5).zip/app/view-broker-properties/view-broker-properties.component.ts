import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-broker-properties',
  templateUrl: './view-broker-properties.component.html',
  styleUrls: ['./view-broker-properties.component.css']
})
export class ViewBrokerPropertiesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
