import { Component, OnInit } from '@angular/core';
import { Owner } from '../Owner';
import { PersonServiceService } from '../person-service.service';

@Component({
  selector: 'app-view-owner',
  templateUrl: './view-owner.component.html',
  styleUrls: ['./view-owner.component.css']
})
export class ViewOwnerComponent implements OnInit {

  owners:Owner[]=[];
  owner: Owner=undefined;
  id: number;
  flag:boolean=false;
  flag1:boolean=false;
  flag2: boolean=false;
  constructor(private service: PersonServiceService) { }

  ngOnInit(): void {
  }

  flag3:boolean=false;
  msg:string;
  getOwners(): void{
   
    this.flag1=false;
    this.flag3=false;
    this.service.getOwners().subscribe((o)=>this.owners=o, (error: Response)=>{
      if(error.status==404)
        this.msg='Sorry no Owners to show';
        this.flag3=false;
        
    }
    );
    if(this.owners!=undefined){
    this.flag=true;
    this.flag2=false;
    }

  }

  getOwner(): void{
    this.flag=false;
    this.flag1=true;

    this.service.getOwner(this.id).subscribe((o)=>this.owner=o, (error: Response)=>{
      if(error.status == 404){
        this.msg='Sorry  owner with id '+ this.id+' not found to show';
        this.flag3=true;
      }
    }
    );
    if(this.owner!=undefined){
    this.flag2=true;
    this.flag3=false;
    this.flag=false;
    }
  }

}
