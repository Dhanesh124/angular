import { Component, OnInit } from '@angular/core';
import { Customer } from '../Customer';
import { PersonServiceService } from '../person-service.service';

@Component({
  selector: 'app-delete-customer',
  templateUrl: './delete-customer.component.html',
  styleUrls: ['./delete-customer.component.css']
})
export class DeleteCustomerComponent implements OnInit {

  id: number;
  customer: Customer;
  msg: string;
  flag: boolean=false;
  
    constructor(private service: PersonServiceService) { }
  
    ngOnInit(): void {
    }
  
    flag1: boolean=false;
deleteCustomer(): void{
    if(this.id!=undefined){
   this.flag1=false;
      this.flag=false;
      this.service.deleteCustomer(this.id).subscribe((b)=>this.customer=b, (error: Response)=>{
        if(error.status== 404)
          this.msg="Sorry Customer with id "+this.id+" not found!!";
      });

      if(this.customer==undefined){
      this.msg="Customer got deleted!!";
      this.flag=true;
  //this.id=undefined;
      }
  
    }else{
   this.flag1=true;
   this.msg="Please Provide Customer Id";
  }
}

}
