import { Component, OnInit } from '@angular/core';
import { Customer } from '../Customer';
import { PersonServiceService } from '../person-service.service';

@Component({
  selector: 'app-view-customer',
  templateUrl: './view-customer.component.html',
  styleUrls: ['./view-customer.component.css']
})
export class ViewCustomerComponent implements OnInit {

  customers:Customer[];
  customer: Customer;
  id: number;
  flag:boolean=false;
  flag1:boolean=false;
  flag2: boolean=false;
  constructor(private service: PersonServiceService) { }

  ngOnInit(): void {
  }

  flag3:boolean=false;
  msg:string;
  getCustomers(): void{
   
    this.flag1=false;
    this.flag3=false;
    this.service.getCustomers().subscribe((c)=>this.customers=c, (error: Response)=>{
      if(error.status==404)
        this.msg='Sorry no Customers to show';
        this.flag3=false;
        
    }
    );
    if(this.customers!=undefined){
    this.flag=true;
    this.flag2=false;
    }

  }

  getCustomer(): void{
    this.flag=false;
    this.flag1=true;

    this.service.getCustomer(this.id).subscribe((c)=>this.customer=c, (error: Response)=>{
      if(error.status == 404){
        this.msg='Sorry  Customer with id '+ this.id+' not found to show';
        this.flag3=true;
      }
    }
    );
    if(this.customer!=undefined){
    this.flag2=true;
    this.flag3=false;

    }
  }
}
