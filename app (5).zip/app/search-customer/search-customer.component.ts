import { Component, OnInit } from '@angular/core';
import { Customer } from '../Customer';
import { PersonServiceService } from '../person-service.service';

@Component({
  selector: 'app-search-customer',
  templateUrl: './search-customer.component.html',
  styleUrls: ['./search-customer.component.css']
})
export class SearchCustomerComponent implements OnInit {
  customers: Customer[];
  searched: Customer[];
  city: string;
  name: string;
  flag:boolean=false;
    constructor(private service: PersonServiceService) { 
        this.service.getCustomers().subscribe((c)=>this.customers=c);
    }
    ngOnInit(): void {
    }
    searchCustomer(): void{
        this.flag=true;
      this.searched=this.customers.filter((c)=>c.customerAddress.city.startsWith(this.city));
    }
    searchCustomerName(): void{
        this.flag=true;
            this.searched=this.customers.filter((c)=>c.customerFirstName.startsWith(this.name));
              }
}
