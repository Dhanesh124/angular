import { Component, OnInit } from '@angular/core';
import { Flat } from '../Flat';
import { PropertyService } from '../property.service';

@Component({
  selector: 'app-search-flat',
  templateUrl: './search-flat.component.html',
  styleUrls: ['./search-flat.component.css']
})
export class SearchFlatComponent implements OnInit {
flats: Flat[];
searched: Flat[];
id:number;
oid:number;
cid:number;
city: string;
name: string;
flag:boolean=false;
  constructor(private service: PropertyService) { 
    this.service.getFlats().subscribe((f)=>this.flats=f);
    
  }

  ngOnInit(): void {
   
  }

  searchFlat(): void{
    this.flag=true;

    this.searched=this.flats.filter((f)=>f.flatAddress.city.startsWith(this.city));

  }

  searchFlatName(): void{
    this.flag=true;
    this.searched=this.flats.filter((f)=>f.flatName.startsWith(this.name));
  }

  searchBrokerFlats(): void{
    this.flag=true;
    this.searched=this.flats.filter((f)=>f.broker.id.toString().startsWith(this.id.toString()));
  }

  searchCustomerFlats(): void{
    this.flag=true;
    this.searched=this.flats.filter((f)=>f.customer.id.toString().startsWith(this.cid.toString()));
  }

  searchOwnerFlats(): void{
    this.flag=true;
    this.searched=this.flats.filter((f)=>f.owner.id.toString().startsWith(this.oid.toString()));
  }

}
