import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchFlatComponent } from './search-flat.component';

describe('SearchFlatComponent', () => {
  let component: SearchFlatComponent;
  let fixture: ComponentFixture<SearchFlatComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SearchFlatComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchFlatComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
