import { Component, OnInit } from '@angular/core';
import { User } from '../User';
import { UserService } from '../user.service';

@Component({
  selector: 'app-view-user',
  templateUrl: './view-user.component.html',
  styleUrls: ['./view-user.component.css']
})
export class ViewUserComponent implements OnInit {
  users:User[];
  user: User;
  id: number;
  flag:boolean=false;
  flag1:boolean=false;
  flag2: boolean=false;
 
  constructor(private service: UserService) { }

  ngOnInit(): void {
  }
  flag3:boolean=false;
  msg:string;
  getUsers(): void{
   
    this.flag1=false;
    this.flag3=false;
    this.service.getUsers().subscribe((u)=>this.users=u, (error: Response)=>{
      if(error.status==404)
        this.msg='Sorry no Users to show';
        this.flag3=false;
        
    }
    );
    if(this.users!=undefined){
    this.flag=true;
    this.flag2=false;
    }

  }

  getUser(): void{
    this.flag=false;
    this.flag1=true;

    this.service.getUser(this.id).subscribe((u)=>this.user=u, (error: Response)=>{
      if(error.status == 404){
        this.msg='Sorry  User with id '+ this.id+' not found to show';
        this.flag3=true;
      }
    }
    );
    if(this.user!=undefined){
    this.flag2=true;
    this.flag3=false;

    }
  }
}
