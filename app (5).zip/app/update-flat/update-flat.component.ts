import { Component, OnInit } from '@angular/core';
import { Flat } from '../Flat';
import { PersonServiceService } from '../person-service.service';
import { PropertyService } from '../property.service';

@Component({
  selector: 'app-update-flat',
  templateUrl: './update-flat.component.html',
  styleUrls: ['./update-flat.component.css']
})
export class UpdateFlatComponent implements OnInit {
  id: number;
  flat: Flat=new Flat();
  msg:string;
  flag: boolean=false;
  flag1: boolean=false;
  flag2: boolean=false;
    constructor(private service: PropertyService, private personService: PersonServiceService) { }
  
    ngOnInit(): void {
    }
    getFlat(): void{
      this.flag1=false;
      this.flag2=false;
      this.service.getFlat(this.id).subscribe((f)=>this.flat=f,(error: Response)=>{
        if(error.status== 404){
          this.msg='Sorry  Flat with id '+ this.id+' not there to update';
          this.flag2=true;
          this.flag=false;
        }
      });
      
      if(this.flat != undefined)
       this.flag2=false;
       this.flag=true;
    }
  
    updateFlat(): void{
      this.personService.getBroker(this.flat.broker.id).subscribe((b)=>this.flat.broker=b, (error: Response)=>{
        if(error.status==404)
          this.msg='Sorry  Broker with id '+ this.flat.broker.id+' not found to add';
         // alert("broker");
         this.flag=true;
      }
      );
      this.personService.getCustomer(this.flat.customer.id).subscribe((b)=>this.flat.customer=b, (error: Response)=>{
        if(error.status==404)
          this.msg='Sorry  Customer with id '+ this.flat.customer.id+' not found to add';
          this.flag=true;
      }
      );
      this.personService.getOwner(this.flat.owner.id).subscribe((b)=>this.flat.owner=b, (error: Response)=>{
        if(error.status==404)
          this.msg='Sorry  Owner with id '+ this.flat.owner.id+' not found to add';
          this.flag=true;
      }
      );
      this.flag1=true;
      this.flag=false;
      this.service.addFlat(this.flat).subscribe((b)=>this.flat=b);
      this.msg="Flat got updated!!";
    }

}
