import { Component, OnInit } from '@angular/core';
import { Broker } from '../Broker';
import { PersonServiceService } from '../person-service.service';

@Component({
  selector: 'app-update-broker',
  templateUrl: './update-broker.component.html',
  styleUrls: ['./update-broker.component.css']
})
export class UpdateBrokerComponent implements OnInit {
id: number;
broker: Broker=new Broker();
msg:string;
flag: boolean=false;
flag1: boolean=false;
flag2: boolean=false;
  constructor(private service: PersonServiceService) { }

  ngOnInit(): void {
  }
  getBroker(): void{
    this.flag1=false;
    this.flag2=false;
    this.service.getBroker(this.id).subscribe((b)=>this.broker=b,(error: Response)=>{
      if(error.status== 404){
        this.msg='Sorry  Broker with id '+ this.id+' not there to update';
        this.flag2=true;
        this.flag=false;
      }
    });
    
    if(this.broker != undefined)
     this.flag2=false;
     this.flag=true;
  }

  updateBroker(): void{
    this.flag1=true;
    this.flag=false;
    this.service.addBroker(this.broker).subscribe((b)=>this.broker=b);
    this.msg="Broker got updated!!";
  }
  

}



