import { Component, OnInit } from '@angular/core';
import { Broker } from '../Broker';
import { PersonServiceService } from '../person-service.service';
import { PropertyService } from '../property.service';

@Component({
  selector: 'app-add-broker',
  templateUrl: './add-broker.component.html',
  styleUrls: ['./add-broker.component.css']
})
export class AddBrokerComponent implements OnInit {
broker : Broker=new Broker();
msg: string;
flag:boolean=false;
  constructor(private service: PersonServiceService, private pService: PropertyService) { }

  ngOnInit(): void {
  }

  addBroker(): void{
   // this.pService.addFlat(this.broker.flat).subscribe((f)=>this.broker.flat=f);
   this.flag=true;
    this.service.addBroker(this.broker).subscribe((b)=>this.broker=b);
    this.msg="broker got added!!";

  }

}
