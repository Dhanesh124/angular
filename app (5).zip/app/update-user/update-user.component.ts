import { Component, OnInit } from '@angular/core';
import { User } from '../User';
import { UserService } from '../user.service';

@Component({
  selector: 'app-update-user',
  templateUrl: './update-user.component.html',
  styleUrls: ['./update-user.component.css']
})
export class UpdateUserComponent implements OnInit {
  id: number;
  user: User=new User();
  msg:string;
  flag: boolean=false;
  flag1: boolean=false;
  flag2: boolean=false;
    constructor(private service: UserService) { }
  
    ngOnInit(): void {
    }
    getUser(): void{
      this.flag1=false;
      this.flag2=false;
      this.service.getUser(this.id).subscribe((o)=>this.user=o,(error: Response)=>{
        if(error.status== 404){
          this.msg='Sorry  User with id '+ this.id+' not there to update';
          this.flag2=true;
          this.flag=false;
        }
      });
      
      if(this.user != undefined)
       this.flag2=false;
       this.flag=true;
    }
  
    updateUser(): void{
      this.flag1=true;
      this.flag=false;
      this.service.registerUser(this.user).subscribe((o)=>this.user=o);
      this.msg="User got updated!!";
    }
}
