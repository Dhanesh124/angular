import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchPlotComponent } from './search-plot.component';

describe('SearchPlotComponent', () => {
  let component: SearchPlotComponent;
  let fixture: ComponentFixture<SearchPlotComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SearchPlotComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchPlotComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
