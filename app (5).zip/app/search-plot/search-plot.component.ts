import { Component, OnInit } from '@angular/core';
import { Plot } from '../Plot';
import { PropertyService } from '../property.service';

@Component({
  selector: 'app-search-plot',
  templateUrl: './search-plot.component.html',
  styleUrls: ['./search-plot.component.css']
})
export class SearchPlotComponent implements OnInit {

  plots: Plot[];
  searched: Plot[];
  city: string;
  name: string;
  flag:boolean=false;
  id: number;
  oid: number;
  cid: number;
    constructor(private service: PropertyService) { 
      this.service.getPlots().subscribe((p)=>this.plots=p);
      
    }
  
    ngOnInit(): void {
     
    }
  
    searchPlot(): void{
      this.flag=true;
  
      this.searched=this.plots.filter((p)=>p.plotAddress.city.startsWith(this.city));
  
    }
  
    searchPlotName(): void{
      this.flag=true;
      this.searched=this.plots.filter((p)=>p.plotName.startsWith(this.name));
    }

    searchBrokerPlots(): void{
      this.flag=true;
      this.searched=this.plots.filter((p)=>p.broker.id.toString().startsWith(this.id.toString()));
    }

    searchCustomerPlots(): void{
      this.flag=true;
      this.searched=this.plots.filter((p)=>p.customer.id.toString().startsWith(this.cid.toString()));
    }

    searchOwnerPlots(): void{
      this.flag=true;
      this.searched=this.plots.filter((p)=>p.owner.id.toString().startsWith(this.oid.toString()));
    }

}
