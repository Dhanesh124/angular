import { Component, OnInit } from '@angular/core';
import { Owner } from '../Owner';
import { PersonServiceService } from '../person-service.service';

@Component({
  selector: 'app-delete-owner',
  templateUrl: './delete-owner.component.html',
  styleUrls: ['./delete-owner.component.css']
})
export class DeleteOwnerComponent implements OnInit {

  id: number;
  owner: Owner;
  msg: string;
  flag: boolean=false;
  
    constructor(private service: PersonServiceService) { }
  
    ngOnInit(): void {
    }
  
    flag1: boolean=false;
    deleteOwner(): void{
      if(this.id!=undefined){
        this.flag1=false;
      this.flag=false;
      this.service.deleteOwner(this.id).subscribe((o)=>this.owner=o, (error: Response)=>{
        if(error.status==404)
          this.msg="Sorry Owner with id "+this.id+" not found!!";
      });
    
      if(this.owner==undefined){
      this.msg="Owner got deleted!!";
      this.flag=true;
      //this.id=undefined;
      }
    }else{
        this.flag1=true;
        this.msg="Please Provide Owner Id";
      }
    }
  

  }
