import { Component, OnInit } from '@angular/core';
import { PropertyService } from '../property.service';
import { Shop } from '../Shop';

@Component({
  selector: 'app-view-shop',
  templateUrl: './view-shop.component.html',
  styleUrls: ['./view-shop.component.css']
})
export class ViewShopComponent implements OnInit {

  shops: Shop[];
  shop: Shop;
  id:  number;
  flag: boolean=false;
  flag1: boolean=false;
  flag2: boolean=false;
  constructor(private service: PropertyService) { }

  ngOnInit(): void {
  }

  flag3:boolean=false;
  msg:string;
  public getShops():void{
    this.flag=true;
    this.flag1=false;
    this.flag2=false;
    this.flag3=false;
    
    this.service.getShops().subscribe((f)=>this.shops=f);
    

  }

  public getShop():void{
    this.flag1=true;
    this.flag=false;
    this.flag3=false;
    this.service.getShop(this.id).subscribe((f)=>this.shop=f, (error: Response)=>{
      if(error.status==404)
        this.msg='Sorry shop with id '+this.id+' not found';
        this.flag3=true;
    }
    );
    if(this.shop!=undefined){
    this.flag2=true;
    this.flag3=false;
    }

  }

  public availableShops(): void{
    this.flag1=false;
    this.flag=true;
    this.flag2=false;
    this.service.availableShops().subscribe((f)=>this.shops=f, (error: Response)=>{
      if(error.status==404)
      this.msg='Sorry no Shops available';
        this.flag=false;
        this.flag3=true;
    }
    );
    if(this.shops!=undefined){
    this.flag=true;
    this.flag3=false;}
  }

  public soldShops(): void{
    this.flag1=false;
    this.flag=true;
    this.flag2=false;
    this.service.soldShops().subscribe((f)=>this.shops=f, (error: Response)=>{
      if(error.status==404)
      this.msg='Sorry no Shops Sold';
        this.flag=false;
        this.flag3=true;
    }
    );
    if(this.shops!=undefined){
    this.flag=true;
    this.flag3=false;}
  }

  public rentedShops(): void{
    this.flag1=false;
    this.flag=true;
    this.flag2=false;
    this.service.rentedShops().subscribe((f)=>this.shops=f, (error: Response)=>{
      if(error.status==404)
      this.msg='Sorry no Shops Rented';
        this.flag=false;
        this.flag3=true;
    }
    );
    if(this.shops!=undefined){
    this.flag=true;
    this.flag3=false;}
  }
}
