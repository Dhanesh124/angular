import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import {HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ViewFlatComponent } from './view-flat/view-flat.component';
import { ViewPlotComponent } from './view-plot/view-plot.component';
import { ViewShopComponent } from './view-shop/view-shop.component';
import { ViewBrokerComponent } from './view-broker/view-broker.component';
import { ViewCustomerComponent } from './view-customer/view-customer.component';
import { ViewOwnerComponent } from './view-owner/view-owner.component';
import { DeleteBrokerComponent } from './delete-broker/delete-broker.component';
import { DeleteCustomerComponent } from './delete-customer/delete-customer.component';
import { DeleteOwnerComponent } from './delete-owner/delete-owner.component';
import { DeleteFlatComponent } from './delete-flat/delete-flat.component';
import { DeletePlotComponent } from './delete-plot/delete-plot.component';
import { DeleteShopComponent } from './delete-shop/delete-shop.component';
import { AddFlatComponent } from './add-flat/add-flat.component';
import { AddBrokerComponent } from './add-broker/add-broker.component';
import { AddCustomerComponent } from './add-customer/add-customer.component';
import { AddOwnerComponent } from './add-owner/add-owner.component';
import { AddPlotComponent } from './add-plot/add-plot.component';
import { AddShopComponent } from './add-shop/add-shop.component';
import { UpdateBrokerComponent } from './update-broker/update-broker.component';
import { UpdateCustomerComponent } from './update-customer/update-customer.component';
import { UpdateOwnerComponent } from './update-owner/update-owner.component';
import { UpdateFlatComponent } from './update-flat/update-flat.component';
import { UpdatePlotComponent } from './update-plot/update-plot.component';
import { UpdateShopComponent } from './update-shop/update-shop.component';
import { BrokerComponent } from './broker/broker.component';
import { CustomerComponent } from './customer/customer.component';

import { FlatComponent } from './flat/flat.component';

import { PlotComponent } from './plot/plot.component';
import { ViewBrokerCustomersComponent } from './view-broker-customers/view-broker-customers.component';
import { ViewBrokerPropertiesComponent } from './view-broker-properties/view-broker-properties.component';
import { SearchBrokerComponent } from './search-broker/search-broker.component';
import { SearchFlatComponent } from './search-flat/search-flat.component';
import { SearchPlotComponent } from './search-plot/search-plot.component';
import { SearchShopComponent } from './search-shop/search-shop.component';
import { SearchCustomerComponent } from './search-customer/search-customer.component';
import { SearchOwnerComponent } from './search-owner/search-owner.component';
import { RegisterUserComponent } from './register-user/register-user.component';
import { LoginComponent } from './login/login.component';
import { UpdateUserComponent } from './update-user/update-user.component';
import { DeleteUserComponent } from './delete-user/delete-user.component';
import { ViewUserComponent } from './view-user/view-user.component';

import { HomeComponent } from './home/home.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AuthGuard } from './auth.guard';
import { NgxPaginationModule } from 'ngx-pagination';

@NgModule({
  declarations: [
    AppComponent,
    ViewFlatComponent,
    ViewPlotComponent,
    ViewShopComponent,
    ViewBrokerComponent,
    ViewCustomerComponent,
    ViewOwnerComponent,
    DeleteBrokerComponent,
    DeleteCustomerComponent,
    DeleteOwnerComponent,
    DeleteFlatComponent,
    DeletePlotComponent,
    DeleteShopComponent,
    AddFlatComponent,
    AddBrokerComponent,
    AddCustomerComponent,
    AddOwnerComponent,
    AddPlotComponent,
    AddShopComponent,
    UpdateBrokerComponent,
    UpdateCustomerComponent,
    UpdateOwnerComponent,
    UpdateFlatComponent,
    UpdatePlotComponent,
    UpdateShopComponent,
    BrokerComponent,
    CustomerComponent,
    FlatComponent,   
    PlotComponent,
    ViewBrokerCustomersComponent,
    ViewBrokerPropertiesComponent,
    SearchBrokerComponent,
    SearchFlatComponent,
    SearchPlotComponent,
    SearchShopComponent,
    SearchCustomerComponent,
    SearchOwnerComponent,
    RegisterUserComponent,
    LoginComponent,
    UpdateUserComponent,
    DeleteUserComponent,
    ViewUserComponent,
    
    HomeComponent,
         DashboardComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    NgxPaginationModule
  ],
  providers: [AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
