import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Flat } from './Flat';
import { Plot } from './Plot';
import { RebApiWebURL } from './RebApiWebURL';
import { Shop } from './Shop';

@Injectable({
  providedIn: 'root'
})
export class PropertyService {
flatUrl: string=RebApiWebURL.flatURL;
plotUrl: string=RebApiWebURL.plotURL;
shopUrl: string=RebApiWebURL.shopURL;


  constructor(private h:HttpClient) { }

  //Getting Flats
  public getFlats(): Observable<any>{
    return this.h.get<any>(this.flatUrl);

  }
//"http://localhost:9090/api/flats"http://localhost:9090/api/flats
  public addFlat(flat: Flat):Observable<any>{
    return this.h.post(this.flatUrl, flat, {responseType: 'text'});

  }

  public getFlat(id: number): Observable<any>{
    return this.h.get<any>(this.flatUrl+"/"+id);
  }

  public deleteFlat(id: number):Observable<any>{
    return this.h.delete(this.flatUrl+"/"+id, {responseType: 'text'});
  }

  public availableFlats(): Observable<any>{
    return this.h.get<any>(this.flatUrl+"/getstatus/"+"available");
  }
  public soldFlats(): Observable<any>{
    return this.h.get<any>(this.flatUrl+"/getstatus/"+"sold");
  }
  public rentedFlats(): Observable<any>{
    return this.h.get<any>(this.flatUrl+"/getstatus/"+"rented");
  }

  //Getting Plots
  public getPlots(): Observable<any>{
    return this.h.get<any>(this.plotUrl);

  }

  public addPlot(plot: Plot):Observable<any>{
    return this.h.post<any>(this.plotUrl, plot);

  }

  public getPlot(id: number): Observable<any>{
    return this.h.get<any>(this.plotUrl+"/"+id);
  }

  public deletePlot(id: number):Observable<any>{
    return this.h.delete(this.plotUrl+"/"+id, {responseType: 'text'});
  }

  public availablePlots(): Observable<any>{
    return this.h.get<any>(this.plotUrl+"/getstatus/"+"available");
  }
  public soldPlots(): Observable<any>{
    return this.h.get<any>(this.plotUrl+"/getstatus/"+"sold");
  }
  //http://localhost:9090/api/plots/getstatus/rented
  public rentedPlots(): Observable<any>{
    return this.h.get<any>(this.plotUrl+"/getstatus/"+"rented");
  }

  //Getting Shop
  public getShops(): Observable<any>{
    return this.h.get<any>(this.shopUrl);

  }

  public addShop(shop: Shop):Observable<any>{
    return this.h.post<any>(this.shopUrl, shop);

  }

  public getShop(id: number): Observable<any>{
    return this.h.get<any>(this.shopUrl+"/"+id);
  }

  public deleteShop(id: number):Observable<any>{
    return this.h.delete(this.shopUrl+"/"+id, {responseType: 'text'});
  }

  public availableShops(): Observable<any>{
    return this.h.get<any>(this.shopUrl+"/getstatus/"+"available");
  }
  public soldShops(): Observable<any>{
    return this.h.get<any>(this.shopUrl+"/getstatus/"+"sold");
  }
  public rentedShops(): Observable<any>{
    return this.h.get<any>(this.shopUrl+"/getstatus/"+"rented");
  }

}
