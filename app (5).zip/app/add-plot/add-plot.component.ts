import { Component, OnInit } from '@angular/core';
import { Broker } from '../Broker';
import { Customer } from '../Customer';
import { Owner } from '../Owner';
import { PersonServiceService } from '../person-service.service';
import { Plot } from '../Plot';
import { PropertyService } from '../property.service';

@Component({
  selector: 'app-add-plot',
  templateUrl: './add-plot.component.html',
  styleUrls: ['./add-plot.component.css']
})
export class AddPlotComponent implements OnInit {
plot: Plot=new Plot();

  constructor(private service: PropertyService, private personService: PersonServiceService) { }

  ngOnInit(): void {
  }

  msg: string;
  flag:boolean=false;

   addPlot(): void{

    this.personService.getBroker(this.plot.broker.id).subscribe((b)=>this.plot.broker=b, (error: Response)=>{
      if(error.status==404)
        this.msg='Sorry  Broker with id '+ this.plot.broker.id+' not found to add';
       // alert("broker");
       this.flag=true;
    }
    );
    this.personService.getCustomer(this.plot.customer.id).subscribe((b)=>this.plot.customer=b, (error: Response)=>{
      if(error.status==404)
        this.msg='Sorry  Customer with id '+ this.plot.customer.id+' not found to add';
        this.flag=true;
    }
    );
    this.personService.getOwner(this.plot.owner.id).subscribe((b)=>this.plot.owner=b, (error: Response)=>{
      if(error.status==404)
        this.msg='Sorry  Owner with id '+ this.plot.owner.id+' not found to add';
        this.flag=true;
    }
    );
    if(this.plot.broker!=null && this.plot.owner!=null){
      this.flag=false;
    this.service.addPlot(this.plot).subscribe((p)=>this.plot=p
    );
   if(this.plot!=undefined)
   this.flag=true;
         this.msg="Plot added";
    }

   }

}
