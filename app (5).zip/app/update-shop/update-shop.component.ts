import { Component, OnInit } from '@angular/core';
import { PropertyService } from '../property.service';
import { Shop } from '../Shop';

@Component({
  selector: 'app-update-shop',
  templateUrl: './update-shop.component.html',
  styleUrls: ['./update-shop.component.css']
})
export class UpdateShopComponent implements OnInit {
  id: number;
  shop: Shop=new Shop();
  msg:string;
  flag: boolean=false;
  flag1: boolean=false;
  flag2: boolean=false;
    constructor(private service: PropertyService) { }
  
    ngOnInit(): void {
    }
    getShop(): void{
      this.flag1=false;
      this.flag2=false;
      this.service.getShop(this.id).subscribe((s)=>this.shop=s,(error: Response)=>{
        if(error.status== 404){
          this.msg='Sorry  Shop with id '+ this.id+' not there to update';
          this.flag2=true;
          this.flag=false;
        }
      });
      
      if(this.shop != undefined)
       this.flag2=false;
       this.flag=true;
    }
  
    updateShop(): void{
      this.flag1=true;
      this.flag=false;
      this.service.addShop(this.shop).subscribe((s)=>this.shop=s);
      this.msg="Shop got updated!!";
    }

}
