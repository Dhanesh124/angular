import { Component, OnInit } from '@angular/core';
import { Broker } from '../Broker';
import { PersonServiceService } from '../person-service.service';

@Component({
  selector: 'app-search-broker',
  templateUrl: './search-broker.component.html',
  styleUrls: ['./search-broker.component.css']
})
export class SearchBrokerComponent implements OnInit {

  brokers: Broker[];
  searched: Broker[];
  city: string;
  name: string;
  flag:boolean=false;
    constructor(private service: PersonServiceService) { 
        this.service.getBrokers().subscribe((b)=>this.brokers=b);
    }
    ngOnInit(): void {
    }
    searchBroker(): void{
        this.flag=true;
      this.searched=this.brokers.filter((b)=>b.brokerAddress.city.startsWith(this.city));
    }
    searchBrokerName(): void{
        this.flag=true;
            this.searched=this.brokers.filter((b)=>b.brokerFirstName.startsWith(this.name));
              }
}
