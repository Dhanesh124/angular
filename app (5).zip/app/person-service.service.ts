import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { RebApiWebURL } from './RebApiWebURL';
import { Observable } from 'rxjs';
import { Broker } from './Broker';
import { Customer } from './Customer';
import { Owner } from './Owner';

@Injectable({
  providedIn: 'root'
})
export class PersonServiceService {
 brokerURL: string=RebApiWebURL.brokerURL;
 customerURL: string=RebApiWebURL.customerURL;
 ownerURL: string=RebApiWebURL.ownerURL;

  constructor(private h:HttpClient) { }

  getBrokers(): Observable<any>{
    return this.h.get<any>(this.brokerURL);
  }
  getBroker(id:  number):Observable<any>{
    return this.h.get<any>(this.brokerURL+"/"+id);
  }
  // getBrokerCustomers(id: number):Observable<any>{
  //   return this.h.get<any>(this.brokerURL+"/customerlist/"+id);
  // }
  // getBrokerFlats(id: number):Observable<any>{
  //   return this.h.get<any>(this.brokerURL+"/flatlist/"+id);
  // }
  // getBrokerPlots(id: number):Observable<any>{
  //   return this.h.get<any>(this.brokerURL+"/plotlist/"+id);
  // }
  // getBrokerShops(id: number):Observable<any>{
  //   return this.h.get<any>(this.brokerURL+"/shoplist/"+id);
  // }
  addBroker(broker: Broker): Observable<any>{
    return this.h.post(this.brokerURL, broker, {responseType: "text"} );
  }
  deleteBroker(id: number):Observable<any>{
    return this.h.delete(this.brokerURL+"/"+id, {responseType: "text"});
  }
  getCustomers(): Observable<any>{
    return this.h.get<any>(this.customerURL);
  }

  getCustomer(id:  number):Observable<any>{
    return this.h.get<any>(this.customerURL+"/"+id);
  }
  addCustomer(customer: Customer): Observable<any>{
    return this.h.post(this.customerURL, customer, {responseType: "text"} );
  }
  deleteCustomer(id: number):Observable<any>{
    return this.h.delete(this.customerURL+"/"+id, {responseType: "text"});
  }

  getOwners(): Observable<any>{
    return this.h.get<any>(this.ownerURL);
  }

  getOwner(id:  number):Observable<any>{
    return this.h.get<any>(this.ownerURL+"/"+id);
  }
  // getOwnerCustomers(id: number):Observable<any>{
  //   return this.h.get<any>(this.ownerURL+"/customerlist/"+id);
  // }
  // getOwnerFlats(id: number):Observable<any>{
  //   return this.h.get<any>(this.ownerURL+"/flatlist/"+id);
  // }
  // getOwnerPlots(id: number):Observable<any>{
  //   return this.h.get<any>(this.ownerURL+"/plotlist/"+id);
  // }
  // getOwnerShops(id: number):Observable<any>{
  //   return this.h.get<any>(this.ownerURL+"/shoplist/"+id);
  // }
  addOwner(owner: Owner): Observable<any>{
    return this.h.post(this.ownerURL, owner, {responseType: "text"} );
  }
  deleteOwner(id: number):Observable<any>{
    return this.h.delete(this.ownerURL+"/"+id, {responseType: "text"});
  }

}
