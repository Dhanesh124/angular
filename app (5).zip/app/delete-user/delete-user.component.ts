import { Component, OnInit } from '@angular/core';
import { User } from '../User';
import { UserService } from '../user.service';

@Component({
  selector: 'app-delete-user',
  templateUrl: './delete-user.component.html',
  styleUrls: ['./delete-user.component.css']
})
export class DeleteUserComponent implements OnInit {
  id: number;
  user: User;
  msg: string;
  flag: boolean=false;
  
  
    constructor(private service: UserService) { }
  
    ngOnInit(): void {
    }
    flag1: boolean=false;
    deleteUser(): void{
      if(this.id!=undefined){
        this.flag1=false;
      this.flag=false;
      this.service.deleteUser(this.id).subscribe((u)=>this.user=u, (error: Response)=>{
        if(error.status==404)
          this.msg="Sorry User with id "+this.id+" not found!!";
      });
    
      if(this.user==undefined){
      this.msg="User got deleted!!";
      this.flag=true;
      //this.id=undefined;
      }
    }else{
      this.flag1=true;
      this.msg="please provide user id";
    }
  
    }

}
