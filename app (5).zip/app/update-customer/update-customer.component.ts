import { Component, OnInit } from '@angular/core';
import { Customer } from '../Customer';
import { PersonServiceService } from '../person-service.service';

@Component({
  selector: 'app-update-customer',
  templateUrl: './update-customer.component.html',
  styleUrls: ['./update-customer.component.css']
})
export class UpdateCustomerComponent implements OnInit {
  id: number;
  customer: Customer=new Customer();
  msg:string;
  flag: boolean=false;
  flag1: boolean=false;
  flag2: boolean=false;
    constructor(private service: PersonServiceService) { }
  
    ngOnInit(): void {
    }
    getCustomer(): void{
      this.flag1=false;
      this.flag2=false;
      this.service.getCustomer(this.id).subscribe((c)=>this.customer=c,(error: Response)=>{
        if(error.status== 404){
          this.msg='Sorry  Customer with id '+ this.id+' not there to update';
          this.flag2=true;
          this.flag=false;
        }
      });
      
      if(this.customer != undefined){
       this.flag2=false;
       this.flag=true;
      }
    }
  
    updateCustomer(): void{
      this.flag1=true;
      this.flag=false;
      // this.service.getBroker(this.customer.broker.id).subscribe((b)=>this.customer.broker=b, (error: Response)=>{
      //   if(error.status==404)
      //     this.msg='Sorry  Broker with id '+ this.customer.broker.id+' not found to add';
      //     alert("broker");
      //   // this.flag=true;
      // }
      // );
      this.service.addCustomer(this.customer).subscribe((c)=>this.customer=c);
      this.msg="Customer got updated!!";
    }

}
